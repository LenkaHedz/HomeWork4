package ua.training.model;

public enum Group {
    USER, ADMIN;
}
